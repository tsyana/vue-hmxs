<template lang="html">
  <div class="contract-page">
    <div class="contract-content">
      <div class="content-components">
        <contract-content></contract-content>
      </div>
    </div>
    <div class="switch-radio">
      <span>我接受协议</span>
      <div class="">
        <mt-switch v-model="value" :disabled="switchDisbaled"></mt-switch>
      </div>
    </div>
    <div class="submit-button">
      <div class="button" :style="{'justify-content': switchDisbaled ? 'center' : 'space-between'}" v-if="png!=''">
        <img :src="png" alt="" class="sig-png">
        <div class="btn-bar"  v-if="!switchDisbaled">
          <mt-button type="primary" @click="goHref()" :disabled="isDisabled" >提交</mt-button>
          <mt-button type="danger" @click="reDraw()" :disabled="isDisabled" >重签</mt-button>
        </div>
      </div>
    </div>
    <mt-popup
      v-model="popupVisible"
      position="bottom"
      :closeOnClickModal="false">
      <div class="">
        <div class="" style="text-align:center;">
          签名
        </div>
        <div class="signature-pad" v-if="showCanvas">
          <vueSignature ref="signature" :sigOption="option" :w="'400px'" :h="'200px'"></vueSignature>
        </div>

        <div class="button-bar">
          <mt-button @click="save" type="primary">保存</mt-button>
          <mt-button @click="clear" type="default">清除</mt-button>
          <mt-button @click="back" type="default">返回</mt-button>
        </div>
      </div>

    </mt-popup>
  </div>
</template>

<script>
import { MessageBox } from 'mint-ui';
import ContractContent from '@/components/ContractContent.vue'; // eslint-disable-line

export default {
    name: 'contract',
    data() {
        return {
            showCanvas: false,
            value: false,
            switchDisbaled: false,
            popupVisible: false,
            option: {
                penColor: 'rgb(0, 0, 0)',
            },
            png: '',
            contractDetail: {},
        };
    },
    mounted() {
        this.value = this.$route.query.status == '0'; // eslint-disable-line
        this.switchDisbaled = this.$route.query.status == '0'; // eslint-disable-line
        const uxInfo = JSON.parse(localStorage.getItem('ux_info'));
        if (this.$route.query.status == '0') { // eslint-disable-line
            this.axios.post('/showEmpContract', { emp_id: uxInfo.emp_id }).then((res) => {
                this.contractDetail = res;
                this.png = res.path;
            });
        }
    },
    components: {
        ContractContent,
    },
    watch: {
        value(val) {
            if (this.$route.query.status == '1') { // eslint-disable-line
                this.popupVisible = this.value;
                if (val) {
                    setTimeout(() => {
                        this.showCanvas = true;
                    }, 50);
                } else {
                    this.png = '';
                    this.$refs.signature.clear();
                }
            }
        },
    },
    computed: {
        isDisabled() {
            return !this.value;
        },
    },
    methods: {
        goHref() {
            const uxInfo = JSON.parse(localStorage.getItem('ux_info'));
            this.axios.post('/signUp', {
                identity_code: uxInfo.identity_code,
                name: uxInfo.name,
                img_data: this.png.split(',')[1],
                emp_id: uxInfo.emp_id,
            }).then((res) => {
                if (res.result == 1) { // eslint-disable-line
                    this.$router.push('/success');
                } else {
                    MessageBox('提示', res.message);
                }
            });
        },
        back() {
            if (this.png === '') {
                this.value = false;
                this.$refs.signature.clear();
            } else {
                this.popupVisible = false;
            }
        },
        reDraw() {
            this.popupVisible = true;
            this.$refs.signature.clear();
        },
        save() {
            const _this = this;
            const png = _this.$refs.signature.save();
            this.png = png;
            this.popupVisible = false;
        },
        clear() {
            const _this = this;
            _this.$refs.signature.clear();
        },
    },
};
</script>

<style lang="less">
.contract-page{
    position: relative;
    height: 100%;
    .mint-header{
      background-color: white;
      color: #2c3e50;
      .mint-header-title{
        font-weight: 600;
      }
    }
    .signature-pad{
      width: 400px;
      height: 200px;
    }
    .contract-content{
      font-size: 14px;
      position: absolute;
      top: 0px;
      bottom: 30%;
      overflow: auto;
      width: 100%;
      .content-components{
        position: absolute;
        top: 0;
        // padding: 15px;
        width: 100%;
        height: 100%;
      }
    }
    .switch-radio{
      position: absolute;
      bottom: 20%;
      z-index: 100;
      width: 100%;
      align-items: center;
      display: flex;
      justify-content: space-between;
      span{
        margin-left: 10px;
      }
      label{
        margin-right: 10px;
      }
    }
    .button-bar{
      .mint-button{
        height: 30px;
        margin-bottom: 10px;
      }
    }
    .submit-button{
      position: absolute;
      bottom: 0%;
      width: 100%;
      .button{
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 10px;
        .btn-bar{
          text-align: right;
          .mint-button{
            height: 30px;
          }
        }
        .sig-png{
          width: 200px;
          height: 100px;
        }
      }
    }
}
</style>
