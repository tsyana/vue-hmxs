<template lang="html">
  <div class="content-page">
    <div class="fullpage-container">
      <div class="fullpage-wp" v-fullpage="opts">
        <div class="page-1 page">
          <div class="content-page-num">
            <h3 class="content-page-left">协议编号：</h3>
            <span></span>
          </div>
          <div class="content-page-title">
            <h1>综合性人力资源</h1>
            <h1>服务协议</h1>
          </div>
          <div class="content-page-jf">
            <h3 class="content-page-jf-header">甲方</h3>
            <h3 class="content-page-jf-name">宁波才烁人力资源服务有限公司</h3>
          </div>
        </div>
        <div class="page-2 page">
          <div class="content-page-content">
            <p><span class="margin-10"></span>鉴于：<br>
            <span class="margin-10"></span>甲方系领先的“一站式”人力资源服务商，致力于提供全方位人力资源外包服务和整体解决方案，
              拥有专业的技术人员团队和服务人员团队。<br>
              <span class="margin-10"></span>甲方可根据自身的行业优势和客户资源为乙方提供灵活兼职、创业学习等综合性人力资源服务，乙方愿意选择甲方的该等服务。
            </p>
            <p><span class="margin-10"></span>根据《中华人民共和国合同法》的相关规定，双方经友好协商一致，
              在互惠互利之基础上达成合作协议如下。</p>
          </div>
          <div class="content-page-header">
            <p>第一条	服务范围</p>
          </div>
          <div class="content-page-detail">
              <span class="margin-10"></span>1.1	人力资源服务项目
              <div class="content-page-detail-list">
                1)	创业伙伴<br>
                2)	创业学习<br>
                3)	创业实践<br>
                4)	灵活兼职<br>
                5)	职业培训<br>
                6)	招聘求职<br>
                7)	保险福利<br>
                8)	双方约定的其他服务
              </div>
            <span class="margin-10"></span>  1.2	服务主体
            <div class="content-page-detail-list">
              本协议框架下的服务主体为甲方。
            </div>
            <span class="margin-10"></span>  1.3	服务对象
            <div class="content-page-detail-list">
                本协议框架下的服务对象乙方。
            </div>
            <span class="margin-10"></span>  1.4	服务内容附件
            <div class="content-page-detail-list">
                双方对某一项具体服务，可以附件的形式明确其内容和双方权利义务。
            </div>
          </div>
        </div>
        <div class="page-3 page">
          <div class="content-page-header">
            <p>第二条	服务费用和报酬</p>
          </div>
          <div class="content-page-detail">
              <span class="margin-10"></span>2.1	服务费用
              <div class="content-page-detail-list">
                乙方向甲方支付的服务费用（若有）将根据具体服务以附件形式约定。
              </div>
            <span class="margin-10"></span>  2.2	乙方报酬
            <div class="content-page-detail-list">
              乙方选择创业伙伴服务的，甲方应根据双方约定的报酬标准向乙方按时足额支付。
            </div>
            <span class="margin-10"></span>  2.3	税金
            <div class="content-page-detail-list">
              涉及任何中国法律规定的税款的，由双方各自承担。
            </div>
          </div>
          <div class="content-page-header">
            <p>第三条	期限和终止</p>
          </div>
          <div class="content-page-detail">
              <span class="margin-10"></span>3.1	合作期限
              <div class="content-page-detail-list">
                本协议的期限一年，从签署之日开始生效。期限届满时，双方可以协商续签事宜,若双方无异议，协议自动续签；未能续签的，
                本协议期满自动终止，无须事先通知对方。
              </div>
            <span class="margin-10"></span>  3.2	提前终止
            <div class="content-page-detail-list">
              任何一方均可在提前15日书面通知对方后而提前终止本协议（包括本协议的所有附件）。
            </div>
            <span class="margin-10"></span>  3.3	违约终止
            <div class="content-page-detail-list">
              任何一方存在违约行为的，在对方发出书面违约更正通知后10日内未能纠正其违约行为的，守约方可立即终止本协议。
            </div>
          </div>
          <div class="content-page-header">
            <p>第四条	责任承担</p>
          </div>
          <div class="content-page-detail">
              <span class="margin-10"></span>4.1	免责范围
          </div>
        </div>
        <div class="page-4 page">
          <div class="content-page-detail">
              <div class="content-page-detail-list">
                不论是否存在违约或侵权行为，任何一方对于对方的间接、附带、后继等非直接损失均不承担赔偿责任。
              </div>
            <span class="margin-10"></span>  4.2	责任限制
            <div class="content-page-detail-list">
              除非在本协议或者本协议附件中有明文约定，否则任何一方无须向对方承担任何非因本方故意或过错所导致的责任。
            </div>
          </div>
          <div class="content-page-header">
            <p>第五条	法律适用</p>
          </div>
          <div class="content-page-detail">
              <span class="margin-10"></span>5.1	本协议由中华人民共和国法律管辖。<br>
              <span class="margin-10"></span>5.2	双方因履行本协议而产生任何争议的，应首先通过友好协商解决；若协商不成的，
              任何一方均可甲方所在地的人民法院起诉。
          </div>
          <div class="content-page-header">
            <p>第六条	不可抗力</p>
          </div>
          <div class="content-page-detail">
              <span class="margin-15"></span>若因自然灾害、政府当局的任何政令、罢工或劳工纠纷、火灾或其他设施障碍、
              以及公用设施停顿、互联网服务供应商发生故障等类似情况造成任何一方迟延或未能履约，该方不应被视为违约，
              并且不应就此向对方承担赔偿责任。在该等情形下，双方应协商寻求合理的变通或替代性方案，或暂停履行本协议。
          </div>
          <div class="content-page-header">
            <p>第七条	履约承诺</p>
          </div>
          <div class="content-page-detail">
              <span class="margin-10"></span>7.1  双方之间相互独立，本协议之签署和履行不应被解释为在双方之间建立了
              合伙、合资、劳动关系或双方互为对方之代理人。<br>
              <span class="margin-10"></span>7.2  在本协议履行期间以及本协议终止之后一年内，乙方保证：
              <div class="content-page-detail-list">
                1)	不会直接或间接地唆使甲方或其关联方的雇员从甲方或其关联方离职；<br>
                2) 不会直接或间接的唆使甲方或其关联方的雇员加入第三方；<br>
              </div>
          </div>
        </div>
        <div class="page-5 page">
          <div class="content-page-detail">
              <div class="content-page-detail-list">
                3) 不会聘用或以任何其他形式提供工作机会给甲方或其关联方的雇员。<br>
                上述“关联方”是指控制甲方、被甲方控制或与甲方处于共同控制下的法律实体。
              </div>
              <span class="margin-10"></span>7.3  乙方违反本7.2条之承诺的，应当向甲方支付违约金人民币十万元整。<br>
              <span class="margin-10"></span>7.4  乙方应当保守甲方的商业秘密以及所有经营信息。
              乙方同意甲方合法地保存并使用其个人信息和资料，包括以网络方式保存和使用。
          </div>
          <div class="content-page-header">
            <p>第八条   其他</p>
          </div>
          <div class="content-page-detail">
              <span class="margin-10"></span>8.1  本协议自双方签订并实际履行之日起生效；本协议一式两份，双方各执一份，具有同等法律效力。<br>
              <span class="margin-10"></span>8.2  本协议附件与本协议不一致的，以附件约定为准。
          </div>
        </div>
        <div class="page-6 page">
          <div class="content-page-partener">
            <h3>合同附件—伙伴合作</h3>
          </div>
          <p class="black justify">&nbsp;&nbsp;欢迎您与CDP公司签署《伙伴合作》（下称“本合作”）
            并通过CDP的业务伙伴每日优鲜系统（以下称“平台”）提供合作。
            <br>
            <br>
            【重点提示】<br>
            &nbsp;&nbsp;1、为维护您的自身权益，在您书面签署本合作之前，请认真阅读全部内容，务必审慎阅读、充分理解各条款内容，
            特别是权利义务条款、法律适用和管辖条款。<br>
            &nbsp;&nbsp;2、当您点击【同意】后，即视为您已作出真实意思表示，认可并签署本合作，
            包括已充分阅读、理解并接受本合作的全部内容，并与CDP公司（下称“甲方”）
            达成一致意见并成为甲方的合作伙伴，此后您不得以未阅读或不理解本合作内容或类似言辞作任何形式的抗辩。
          </p>

          <div class="content-page-detail">
              <span class="margin-10"></span><span class="black">一、合作内容</span>
              <div class="content-page-detail-list">
                1.1 为甲方或甲方业务伙伴的第三方配送物品（如商品、食品等）；<br>
                1.2 为甲方或甲方业务伙伴的第三方整理、打包货物；<br>
                1.3 甲方或甲方业务伙伴指定乙方完成的其他事项；<br>
                1.4 甲方和甲方业务伙伴有权对乙方的服务成果进行验收。<br>
                1.5 甲方应及时按“任务制”模式向乙方结算合作报酬。<br>
                1.6 甲方可以自主决定为乙方购买保险，相关保险费用由甲方承担。<br>
                1.7 乙方应根据甲方或甲方业务伙伴的安排及要求完成相关的事项，乙方应遵守相关的服务规则、
                相关的法律法规政策规定、职业道德，不得侵犯第三方合法权益。<br>

              </div>
          </div>
        </div>
        <div class="page-7 page">
          <div class="content-page-detail">
            <div class="content-page-detail-list">
              1.8 乙方应遵守甲方及甲方业务伙伴就相关服务的约定及服务标准；
              因乙方给甲方或甲方业务伙伴造成经济损失的，甲方及甲方业务伙伴有权要求乙方进行赔偿。<br>
              1.9 除本合作约定外，乙方不能以甲方及/或甲方业务伙伴的名义开展任何与完成本合作无关的业务或活动，
              且不得从事有损于甲方及甲方业务伙伴声誉的行为。
            </div>
          </div>
          <br>
          <div class="content-page-detail">
              <span class="margin-10"></span><span class="black">二、合作报酬</span>
              <div class="content-page-detail-list">
                2.1 甲方将根据甲方以及甲方业务伙伴的服务要求及业务结算规则，按时向乙方支付合作报酬，
                该等业务结算规则根据市场状况需要会有浮动调整，乙方清楚并了解该等浮动调整为正常情况。<br>
                2.2 乙方应如实向甲方提供银行账户信息。甲方支付合作报酬以乙方提供的收款帐户为准，因乙方提供的收款帐户不实造成的一切损失由乙方自行承担。
                如乙方帐号变更或发生不可用等情况时，应及时进行变更操作；
                否则，由此造成的一切损失由乙方自行负责。<br>
              </div>
          </div>
          <br>
          <div class="content-page-detail">
              <span class="margin-10"></span><span class="black">三、保密</span>
              <div class="content-page-detail-list">
              乙方应在甲方以及甲方业务伙伴许可范围内使用相关的商业信息；协议期内以及协议终止后，
              乙方均有义务对双方合作的有关协议及合作过程中知悉的甲方以及甲方合作伙伴相关信息予以保密，
              不得以任何方式向其它方泄漏、给予或转让该等保密信息。
              </div>
          </div>
          <br>
          <div class="content-page-detail">
              <span class="margin-10"></span><span class="black">四、违约责任</span>
              <div class="content-page-detail-list">
              4.1 双方应按本合作约定履行，如有违反，守约方有权要求对方及时改正；造成对方损失的，守约方有权要求违约方赔偿。
              </div>
          </div>
        </div>
        <div class="page-8 page">
          <div class="content-page-detail">
              <div class="content-page-detail-list">
              4.2 因不可抗力造成损失的，彼此不负赔偿责任，但发生不可抗力一方应及时将有关情况通知另一方，
              并尽最大努力进行补救。本合作所称不可抗力是指不能预见、不能克服并不能避免且对一方当事人造成重大影响的客观事件，
              包括但不限于自然灾害（如：洪水、地震、火灾和风暴等）以及社会事件（如：战争、动乱、政府行为、黑客事件、
              大范围电信事故等）。
              </div>
          </div>
          <br>
          <div class="content-page-detail">
              <span class="margin-10"></span><span class="black">五、特别约定</span>
              <div class="content-page-detail-list">
                5.1 乙方属于甲方人员，与甲方业务伙伴不产生关联，亦无任何劳动或雇用关系。<br>
                5.2 除本合作约定内容外，甲方和甲方业务伙伴无须对乙方承担任何其他义务。<br>
                5.3 乙方不得直接收取甲方业务伙伴的任何款项。<br>
                5.4 若乙方与甲方业务伙伴产生任何纠纷的，应由甲方协调处理。<br>
                5.5 合作期间，乙方应服从甲方及甲方业务伙伴的安排和调度。<br>
                5.6 合作期间，乙方有权利同时或另行选择甲方的其他人力资源服务。
              </div>
          </div>
          <br>
          <div class="content-page-detail">
              <span class="margin-10"></span><span class="black">六、合作期限</span>
              <div class="content-page-detail-list">
                6.1 合作期限自本协议签署之日起一年。<br>
                6.2 合作期限届满，双方可协商续签本合作；未能续签的，合作期满终止。<br>
                6.3 合作期间，任何一方可提前10日书面通知对方而提前本合作。<br>
                6.4 任何一方违反本合作约定，且违约方在守约方书面通知后7日内仍未予改正的，
                守约方可以书面通知的形式提前终止本合作。<br>


              </div>
          </div>
        </div>
        <div class="page-9 page">
          <div class="content-page-detail">
            <div class="content-page-detail-list">
              6.5 本合作的提前终止不影响已经产生的权利义务关系。<br>
              6.6 本合作的订立、履行和解释及争议的解决适用中国法律法规。<br>
              6.7 因履行本合作发生的纠纷，双方应友好协商解决，协商不成的，可向平台签订地的人民法院诉讼解决。
              <br><br>
              <span class="margin-15"></span>本人已读懂并理解上述全部内容，愿意签署并履行。
              <br>  <br>
              <br>
              甲方：宁波才烁人力资源服务有限公司    <br>
              地址：浙江省宁波市北仑区梅山商务中心二号办公楼527室    <br>
              联系人：蒋琛桦    <br>
              联系电话：021-33295738    <br>
              <br>  <br>
              乙方：<br>
              身份证号：<br>
              联系电话：<br>
              签署日期：<br>


            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
    data() {
        return {
            opts: {
                start: 0,
                dir: 'v',
                duration: 500,
            },
        };
    },
};
</script>

<style lang="less">
.content-page{
  padding: 0 15px;
  height: 100%;
  .page{
    overflow: auto;
  }
  &-num{
    display: flex;
    justify-content: flex-end;
    font-size: 12px;
    align-items: center;
    h3{
      font-weight: 300;
    }
    span{
      width: 50px;
    }
  }
  &-title{
    margin-top: 50px;
  }
  &-jf{
    margin-top: 50px;

    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    &-name{
        border-bottom: 1px solid;
        width: 270px;
    }
  }
  &-content{
    text-align: left;
    font-size: 12px;
  }
  &-header{
    text-align: center;
    font-weight: 600;
  }
  .margin-10{
    display: inline-block;
    margin-left: 5px;
  }
  .margin-15{
    display: inline-block;
    margin-left: 15px;
  }
  .black{
    font-weight: 600;
  }
  &-detail{
    text-align: left;
    font-size: 12px;
    &-list{
      margin-left: 15px;
    }
  }
  &-partener{

  }
  p.justify{
    text-align: justify;
    font-size: 12px;
  }
}
</style>
