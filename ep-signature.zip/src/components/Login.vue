<template>
  <div class="login-page">
    <img src="@/assets/sso-app-logo.png" alt="" class="logo">
    <mt-field label="姓名" placeholder="请输入姓名" v-model="name"></mt-field>
    <mt-field label="身份证" placeholder="请输入身份证"  v-model="identity_code"></mt-field>
    <mt-field label="手机号后6位" placeholder="请输入注册手机号后6位"  v-model="phone_number"></mt-field>
    <div class="login-button">
      <mt-button size="large" type="danger" @click="goHref()">登录</mt-button>
    </div>
  </div>
</template>

<script>
import { MessageBox } from 'mint-ui';

export default {
    data() {
        return {
            name: '',
            identity_code: '',
            phone_number: '',
        };
    },
    methods: {
        goHref() {
            this.axios.post('/loginIn', {
                identity_code: this.identity_code.trim(),
                name: this.name.trim(),
                phone_number: this.phone_number.trim(),
            }).then((res) => {
                res.identity_code = this.identity_code.trim();
                res.name = this.name.trim();
                res.phone_number = this.phone_number.trim();
                localStorage.setItem('ux_info', JSON.stringify(res));
                if (!res.result) {
                    MessageBox('提示', res.message);
                } else if (res.need_id_card) {
                    this.$router.push({
                        path: '/ocr',
                    });
                } else {
                    this.$router.push({
                        path: '/contract',
                        query: {
                            status: res.need_sign_up,
                        },
                    });
                }
            });
        },
    },
};
</script>

<style lang="less">
  .login-page{
    .mint-field .mint-cell-title{
      text-align: left;
    }
    .logo{
      width: 80%;
      margin: 10%;
    }
    .login-button{
      margin: 40px 10px 0px;
    }
  }
</style>
