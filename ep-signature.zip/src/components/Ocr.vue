<template lang="html">
  <div class="ocr-page">
    <div class="card-part">
      <span>身份证照片面</span>
      <img :src="idFont" alt="" class="upload-file" style="opacity:1"  v-if="idFont != ''">
      <input type="file"
       class="upload-file" @change="uploadFile"
       accept="image/jpeg,image/jpg,image/png" capture="camera">
    </div>
    <div class="card-part">
      <span>身份证有效期面</span>
      <img :src="idBack" alt="" class="upload-file" style="opacity:1" v-if="idBack != ''">
      <input type="file"
       class="upload-file" @change="uploadFile2"
       accept="image/jpeg,image/jpg,image/png" capture="camera">
    </div>
    <div class="upload-btn">
      <mt-button type="danger" size="large" @click="postImg">提交</mt-button>
    </div>
  </div>
</template>

<script>
import { MessageBox } from 'mint-ui';

export default {
    data() {
        return {
            idFont: '',
            idBack: '',
            idCard: '',
            state: 'false',
        };
    },
    methods: {
        compress(img) {
            // const initSize = img.src.length;
            let width = img.width;
            let height = img.height;

            // 如果图片大于四百万像素，计算压缩比并将大小压至400万以下
            let ratio;
            if ((ratio = width * height / 1048576) > 1) { // eslint-disable-line
                ratio = Math.sqrt(ratio); // eslint-disable-line
                width /= ratio;
                height /= ratio;
            } else {
                ratio = 1;
            }
            const canvas = document.createElement('canvas');
            const tCanvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;

            //  铺底色
            const ctx = canvas.getContext('2d');
            const tctx = tCanvas.getContext('2d');
            ctx.fillStyle = '#fff';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // 如果图片像素大于100万则使用瓦片绘制
            let count;
            if ((count = width * height / 1000000) > 1) { // eslint-disable-line
                // 计算要分成多少块瓦片s
                count = ~~(Math.sqrt(count) + 1); // eslint-disable-line

                //   计算每块瓦片的宽和高
              const nw = ~~(width / count); // eslint-disable-line
              const nh = ~~(height / count); // eslint-disable-line


                tCanvas.width = nw;
                tCanvas.height = nh;

                for (let i = 0; i < count; i += 1) {
                    for (let j = 0; j < count; j += 1) {
                        tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);

                        ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
                    }
                }
            } else {
                ctx.drawImage(img, 0, 0, width, height);
            }

            // 进行最小压缩
            const ndata = canvas.toDataURL('image/jpeg', 0.1);

            tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0; // eslint-disable-line

            return ndata;
        },
        uploadFile(event) {
            const _self = this;
            const files = event.target.files;
            const reader = new FileReader();
            if (files.length) {
                reader.readAsDataURL(files[0]);
                reader.onload = function (e) { // eslint-disable-line
                    _self.loadImage(e, 'idFont');
                };
            }
        },
        uploadFile2(event) {
            const _self = this;
            const files = event.target.files;
            const reader = new FileReader();
            if (files.length) {
                reader.readAsDataURL(files[0]);
                reader.onload = function (e) { // eslint-disable-line
                    _self.loadImage(e, 'idBack');
                };
            }
        },
        loadImage(e, side) {
            const _self = this;
            const img = new Image();
            img.src = e.target.result;
            if (e.target.result.length > 1048576) {
                img.onload = function () { // eslint-disable-line
                    _self[side] = _self.compress(img);
                };
            } else {
                _self[side] = e.target.result;
            }
        },
        postImg() {
            this.showLoad = true;
            const uxInfo = JSON.parse(localStorage.getItem('ux_info'));
            const argsJsonFace = { // 照片识别 有照片为back面 有效期面为face面
                identity_code: uxInfo.identity_code,
                img_data: this.idFont.split(',')[1],
                name: uxInfo.name,
                side: 'back',
                emp_id: uxInfo.emp_id,
            };
            const argsJsonBack = {
                identity_code: uxInfo.identity_code,
                img_data: this.idBack.split(',')[1],
                name: uxInfo.name,
                side: 'face',
                emp_id: uxInfo.emp_id,
            };
            this.axios.post('/IDCardIdentify', argsJsonFace).then((res) => {
                if (res.result == 1) { // eslint-disable-line
                    this.axios.post('/IDCardIdentify', argsJsonBack).then((backres) => {
                        if (backres.result == 1) { // eslint-disable-line
                            this.$router.push({
                                path: '/contract',
                                query: {
                                    status: 1,
                                },
                            });
                        } else {
                            MessageBox('提示', backres.message);
                        }
                    });
                } else {
                    MessageBox('提示', res.message);
                }
            });
        },
    },
};
</script>

<style lang="less">
.ocr-page{
  width: 100%;
  height: 100%;
  .card-part{
    margin: 10%;
    height: 200px;
    border: 1px dashed lightgrey;
    position: relative;
    img{
      width: 100%;
      height: 100%;
    }
    span{
      display: inline-block;
      color: lightgray;
      line-height: 200px;
    }
    .upload-file{
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      opacity: 0;
    }
  }
  .describe-part{
    margin: 10%;
    text-align: left;
  }
  .loading-part{
    display: flex;
    justify-content: center;
    margin-top: 20px;
  }
  .upload-btn{
    width: 80%;
    margin: 10%;
    position: relative;

  }
}
</style>
