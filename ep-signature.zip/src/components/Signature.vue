<template lang="html">
  <div class="signature-page">
    <mt-header fixed title="signature">
      <router-link to="/contract" slot="left">
       <mt-button icon="back">返回</mt-button>
     </router-link>
    </mt-header>
    <div class="signature-pad">
      <vueSignature ref="signature" :sigOption="option" :w="'100%'" :h="'400px'"></vueSignature>
    </div>

    <div class="button-bar">
      <mt-button @click="save" type="primary">确定</mt-button>
      <mt-button @click="clear" type="default">清除</mt-button>
    </div>

  </div>
</template>

<script>
export default {
    data() {
        return {
            option: {
                penColor: 'rgb(0, 0, 0)',
            },
            png: '',
        };
    },
    methods: {
        save() {
            const _this = this;
            const png = _this.$refs.signature.save();
            const jpeg = _this.$refs.signature.save('image/jpeg');
            const svg = _this.$refs.signature.save('image/svg+xml');
            console.log(png);
            console.log(jpeg);
            console.log(svg);
        },
        clear() {
            const _this = this;
            _this.$refs.signature.clear();
        },
    },
};

</script>

<style lang="less">
.signature-page{
  .mint-header{
    background-color: white;
    color: #2c3e50;
    .mint-header-title{
      font-weight: 600;
    }
  }
  .signature-pad{
    margin-top: 40px;
    border:  1px solid lightgrey;
    margin-bottom: 15px;
  }
  .button-bar{
    display: flex;
    justify-content: space-around;
  }
}
</style>
