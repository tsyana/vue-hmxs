<template lang="html">
  <div class="success-page">
    <img src="@/assets/icon_03.png" alt="">
    <h3>您已成功验证</h3>
  </div>
</template>

<script>
export default {
};
</script>

<style lang="less">
.success-page{
    position: absolute;
   top:30%;
   left:50%;
   transform:translate(-50%,-50%);
}
</style>
