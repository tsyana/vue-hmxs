const ENV = process.env.NODE_ENV;

const baseConfig = {
    development: {
        baseUrl: 'http://10.75.8.126/ws.php/customization/dailyFresh/DailyFreshApiService/',
    },
    test: {
        baseUrl: 'http://10.75.8.126/ws.php/customization/dailyFresh/DailyFreshApiService/',
    },
    uat: {
        baseUrl: 'http://10.75.8.126/ws.php/customization/dailyFresh/DailyFreshApiService/',
    },
    production: {
        baseUrl: 'http://star-test.cdpyun.com/ws.php/customization/dailyFresh/DailyFreshApiService/',
    },
};

module.exports = {
    env: baseConfig[ENV],
};
