import Vue from 'vue';
import Router from 'vue-router';
import Login from '@/components/Login';
import Contract from '@/components/Contract';
import Signature from '@/components/Signature';
import Success from '@/components/Success'; // eslint-disable-line
import Ocr from '@/components/Ocr'; // eslint-disable-inline

Vue.use(Router);

export default new Router({
    routes: [
        {
            path: '/',
            name: 'Login',
            component: Login,
        },
        {
            path: '/contract',
            component: Contract,
        },
        {
            path: '/signature',
            component: Signature,
        },
        {
            path: '/success',
            component: Success,
        },
        {
            path: '/ocr',
            component: Ocr,
        },
    ],
});
